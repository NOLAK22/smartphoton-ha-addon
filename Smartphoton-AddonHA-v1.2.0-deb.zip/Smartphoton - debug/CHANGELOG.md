## 1.2.0
- Ajout Nombre d'onduleur
- info sur les onduleurs secondaires

## 1.1.5
- Correction du mode onduleur

## 1.1.4
- Correction sur la création des sensors mppt
- Correction sur la création du sensor nombre de batterie
- Correction parametre 2 pour onduleur parallèle

## 1.1.3
- Mise à jour base-nodejs en v0.1.2
- Mise à jour addon node red en v17.0.3
- Ajout debug vision
- Ajout Version sur les appareils mqtt

## 1.1.2
- Ajout deuxième entrée mppt

## 1.1.1
- Ajout de l'option Aucune sur le choix des batteries

## 1.1.0
- Mise à jour de certaines aplications
- Mise à jour alpine v3.19
- Mise à jour De addon-node-red v17.0.2 (v3.1.3)

## 1.0.0

